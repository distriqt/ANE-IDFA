[[IDFA AIR Native Extension|Home]]

---

Setup the Extension

1. [[Add the Extension|i.Add the Extension]]
2. [[Initialise the Extension|i.Initialise the Extension]]


--- 

Usage



---

External Links

- [ASdocs](https://distriqt.github.io/ANE-IDFA/asdocs/)
